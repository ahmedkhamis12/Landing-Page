# Landing Page Project
# Project Description
An interactive landing page by using html and css and js, the page has 4 sections add 4 sections in navbar which is built dynamically added dynamically if we click on section in the navbar menu it goes automatically to the related section and it highlighted in navbar which section is active and main section in the page also has different style when it is active,when scroll it scrolls smooth not fast and active section appears
# Table of contents
navbar is built dynamically and add li tags to it using .innerHTML and appendChild() to add them to navbar,i used getBoundingClientRect() to get size of a section to detect is it in the viewport or not to add to it active class,and addEventListener() to when click on section in navbar it goes to related section in the page and i prevent any default action by using preventDefault() and to scroll smoothy i used 
scrollIntoView() and it takes behavior:smooth to scroll to related section smooth
# How to Install and Run the Project
Download the zip file and extract it and open index